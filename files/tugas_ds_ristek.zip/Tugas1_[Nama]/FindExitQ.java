import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Stack;


public class FindExitQ {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		String [] input = bfr.readLine().split(" ");
		int n = Integer.parseInt(input[0]);
		int x = Integer.parseInt(input[1]);
		int y = Integer.parseInt(input[2]);
		char [][] grid = new char[n][n]; 
		for(int ii = 0; ii < n; ii++){
			grid[ii] = bfr.readLine().toCharArray();
		}
		Problem problem = new Problem(grid);
		Node solution = problem.searchSolution(new State(x,y));
		Stack<String> sol = new Stack<String>();
		while(solution.parent != null){
			sol.push(solution.state.action);
			solution = solution.parent;
		}
		while(!sol.isEmpty()){
			System.out.println(sol.pop());
		}
		
	}

}

class Problem{
	public char[][] grid;
	
	public Problem(char[][] grid){
		this.grid = grid;
	}
	public boolean goalState(State thatState){
		/*
		* Definisikan kapan suatu state merupakan solusi dari permasalahan.
		*
		*/
		return false;
	}
	
	public ArrayList<State> successorFunction(State state){
		ArrayList<State> arr = new ArrayList<State>();
		String [] actions = {"Up","Down","Left","Right"};
		
		int x = state.x;
		int y = state.y;
		/*
		 * Your Code Here
		 *
		 * Yang perlu Anda lakukan dalam method ini adalah mengembalikan kumpulan
		 * State yang dikumpulkan dalam ArrayList arr.
		 * Untuk setiap action pada actions, anda perlu definisikan kembali ke sistem koordinat,
		 * misalnya untuk Up, y = y - 1 .		 
		 * Setelah Anda definisikan arti dari Up,Down,Left,Right, anda perlu melakukan validasi, misalnya
		 * posisi agent tidak boleh berada dalam dinding '#'
		 *
		 *
		 */
		return arr;
	}
	
	public Node searchSolution(State initialState){
		LinkedList<Node> queue = new LinkedList<Node>();
		HashSet<Node> visited = new HashSet<Node>();
		Node init = new Node(null,initialState);
		queue.add(init);
		while(!queue.isEmpty()){
			Node node = queue.poll();
			State state = node.state;
			if (goalState(state)){
				return node;
			}else{
				if(!visited.contains(node)){
					visited.add(node);
					ArrayList<State> successors = successorFunction(state);
					for(State s : successors){
						Node newNode = new Node(node,s);
						queue.add(newNode);
					}
				}
			}
		}
		return null;
	}
	
}
class State{
	public int x;
	public int y;
	public String action;
	/*
	 * YOUR CODE HERE
	 * Yang perlu Anda lakukan pada bagian ini adalah implementasi
	 * constructor untuk kelas ini
	 */
}
class Node{
	public Node parent;
	public State state;
	
	public Node(Node parent, State state){
		this.parent = parent;
		this.state = state;
	}
}
