#!/bin/bash

# Move directory
cd /sys/class/gpio

# Activate GPIO 27
echo 27 > export

# Move to GPIO 27
cd gpio27

# Make direction out
echo out > direction

# Write digital value 1
echo 1 > value

# Write digital value 0
echo 0 > value
