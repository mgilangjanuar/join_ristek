#!/bin/bash

# Isi dengan setup GPIO

while true
do
	# Isi dengan potongan kode
	sleep 0.25
done
